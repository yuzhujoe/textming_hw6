example use: python eval.py dev.csv your_output_file dev.gold

line format:
dev.csv: <item_id> <user_id>
your_output_file: <score_for_pair_in_first_argument>
dev.gold: <gold_score_for_pair_in_first_argument>

note the all three input files must be at same length
